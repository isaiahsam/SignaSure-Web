================================================================================
SignaSure - Configuration Files Package
================================================================================

Welcome to the SignaSure project!

This package contains all the configuration files you need to run the
SignaSure app on your local machine.

================================================================================
WHAT'S INCLUDED
================================================================================

1. google-services.json  - Firebase Android configuration
2. upload-keystore.jks   - App signing keystore (for release builds)
3. key.properties        - Keystore credentials
4. firebase.json         - Firebase project configuration
5. env_template.txt      - Environment variables template
6. CONFIG_PACKAGE_README.txt - This file

================================================================================
WHERE TO PLACE THE FILES
================================================================================

After cloning the SignaSure repository, place these files in the following
locations:

1. google-services.json
   Location: android/app/google-services.json

   SignaSure/
   └── android/
       └── app/
           └── google-services.json  <-- Place here

2. upload-keystore.jks
   Location: android/app/upload-keystore.jks

   SignaSure/
   └── android/
       └── app/
           └── upload-keystore.jks  <-- Place here

3. key.properties
   Location: android/key.properties

   SignaSure/
   └── android/
       └── key.properties  <-- Place here

4. firebase.json
   Location: firebase.json (project root)

   SignaSure/
   └── firebase.json  <-- Place here

5. .env
   Location: .env (project root)

   Rename "env_template.txt" to ".env" and place in project root

   SignaSure/
   └── .env  <-- Rename and place here

================================================================================
STEP-BY-STEP INSTRUCTIONS
================================================================================

Step 1: Clone the Repository
-----------------------------
Open your terminal and run:

    git clone https://github.com/yourusername/SignaSure.git
    cd SignaSure


Step 2: Extract This Package
-----------------------------
Extract the SignaSure_Config_Files.zip to a temporary location.


Step 3: Copy Files to Correct Locations
----------------------------------------

Option A - Manual Copy:
  1. Open the extracted folder
  2. Copy each file to its correct location (see above)
  3. Make sure the folder structure matches exactly

Option B - Using Command Line (Windows):

  # From the extracted folder location:
  copy google-services.json "C:\path\to\SignaSure\android\app\"
  copy upload-keystore.jks "C:\path\to\SignaSure\android\app\"
  copy key.properties "C:\path\to\SignaSure\android\"
  copy firebase.json "C:\path\to\SignaSure\"
  ren env_template.txt .env
  copy .env "C:\path\to\SignaSure\"


Step 4: Create local.properties
--------------------------------
Create a NEW file: android/local.properties

Content (replace with YOUR actual paths):

    sdk.dir=C:\\Users\\YourUsername\\AppData\\Local\\Android\\Sdk
    flutter.sdk=C:\\flutter
    flutter.buildMode=debug
    flutter.versionName=1.0.0
    flutter.versionCode=1

To find your Android SDK path:
  - Open Android Studio
  - Go to: File → Settings → System Settings → Android SDK
  - Copy the "Android SDK Location"

To find your Flutter SDK path:
  - Windows: Run "where flutter" in Command Prompt
  - macOS/Linux: Run "which flutter" in Terminal
  - Use everything before "/bin/flutter"


Step 5: Install Dependencies
-----------------------------
Open terminal in the SignaSure folder and run:

    flutter pub get


Step 6: Verify Setup
---------------------
Run these commands to check everything is working:

    flutter doctor -v
    flutter analyze
    flutter devices


Step 7: Run the App
--------------------
    flutter run

The first build takes 5-10 minutes. Be patient!

================================================================================
FILE VERIFICATION CHECKLIST
================================================================================

After placing all files, your project structure should look like this:

SignaSure/
├── .env                              ✓ From this package
├── .gitignore                        ✓ Already in Git
├── pubspec.yaml                      ✓ Already in Git
├── firebase.json                     ✓ From this package
├── TEAM_SETUP_GUIDE.md              ✓ Already in Git
├── QUICK_START.md                   ✓ Already in Git
├── android/
│   ├── app/
│   │   ├── google-services.json      ✓ From this package
│   │   ├── upload-keystore.jks       ✓ From this package
│   │   └── build.gradle              ✓ Already in Git
│   ├── key.properties                ✓ From this package
│   └── local.properties              ✓ YOU create this
├── lib/
│   └── ... (all Flutter code)        ✓ Already in Git
└── assets/
    └── ...                           ✓ Already in Git

================================================================================
IMPORTANT SECURITY NOTES
================================================================================

⚠️  DO NOT commit these files to Git:
    - .env
    - android/key.properties
    - android/app/google-services.json
    - android/app/upload-keystore.jks
    - firebase.json
    - android/local.properties

    These files are already in .gitignore, but always check before pushing!

🔒  Keep the keystore file secure:
    - upload-keystore.jks is CRITICAL
    - If lost, the app cannot be updated on Play Store
    - Never share it publicly

================================================================================
TROUBLESHOOTING
================================================================================

Issue: "google-services.json not found"
Solution: Ensure the file is in android/app/ (not android/)

Issue: "Flutter SDK not found"
Solution: Check android/local.properties has correct paths with double
          backslashes on Windows (C:\\Users\\...)

Issue: "GEMINI_API_KEY not found"
Solution:
  1. Ensure .env file exists in project root
  2. Verify it's named exactly ".env" (not ".env.txt")
  3. Check no extra spaces: GEMINI_API_KEY=AIzaSy...
  4. Run: flutter clean && flutter pub get

Issue: "Gradle build failed"
Solution:
  flutter clean
  cd android
  gradlew clean    (Windows: gradlew.bat clean)
  cd ..
  flutter pub get
  flutter run

Issue: "No devices found"
Solution:
  adb kill-server
  adb start-server
  flutter devices

================================================================================
GETTING HELP
================================================================================

📖 Documentation:
   - Quick Start: See QUICK_START.md in the repository
   - Full Setup Guide: See TEAM_SETUP_GUIDE.md in the repository
   - Project README: See README.md in the repository

🔗 Resources:
   - Flutter Docs: https://flutter.dev/docs
   - Firebase Docs: https://firebase.google.com/docs
   - Gemini API: https://ai.google.dev/

👥 Contact:
   - Team Lead: [Add contact info]
   - Jira Board: [Add link]
   - Team Chat: [Add Slack/Teams channel]

================================================================================
QUICK REFERENCE
================================================================================

Essential Commands:
  flutter pub get          - Install dependencies
  flutter doctor           - Check Flutter installation
  flutter devices          - List connected devices
  flutter run              - Run app in debug mode
  flutter clean            - Clean build cache
  flutter analyze          - Check for code issues

Git Commands:
  git status               - Check current status
  git pull                 - Get latest changes
  git checkout -b branch   - Create new branch

================================================================================

That's it! Follow the steps above and you'll have SignaSure running
in about 30 minutes.

Welcome to the team! 🚀

================================================================================
Last Updated: December 2025
Version: 1.0.0
Developed by Looma Labs
================================================================================
